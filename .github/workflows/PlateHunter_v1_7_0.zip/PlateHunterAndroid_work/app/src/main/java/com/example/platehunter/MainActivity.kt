package com.example.platehunter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val BG = 0xFF0E141B.toInt()
    private val CARD = 0xFF17202B.toInt()
    private val STROKE = 0xFF243140.toInt()
    private val FIELD = 0xFF0F161D.toInt()
    private val TEAL = 0xFF4CC3B0.toInt()
    private val RED = 0xFFFF6B6B.toInt()
    private val TEXT = 0xFFE8EEF4.toInt()
    private val MUTED = 0xFF8A97A6.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var status: TextView
    private lateinit var spoken: TextView
    private lateinit var recordsBox: LinearLayout
    private lateinit var listenButton: Button
    private lateinit var nameEdit: EditText
    private lateinit var platesCount: TextView
    private lateinit var wantedCount: TextView
    private lateinit var wantedHeader: TextView
    private lateinit var lastPlateView: TextView
    private val letterBoxes = mutableListOf<TextView>()
    private val digitBoxes = mutableListOf<TextView>()

    private var sr: SpeechRecognizer? = null
    private var listening = false
    private val records = mutableListOf<JSONObject>()
    private val wanted = mutableSetOf<String>()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private var cloudSpeech: CloudSpeech? = null
    private var liveSpeech: GeminiLiveSpeech? = null
    private var lastLoc: Location? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val assembler = PlateAssembler()
    private var utterStamp: PlateAssembler.Stamp? = null
    private var idCounter = 0L
    private val prefs by lazy { getSharedPreferences("platehunter_settings", MODE_PRIVATE) }
    private fun mode(): Int = prefs.getInt("mode", 0).coerceIn(0, 3)

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) { lastLoc = location }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onStatusChanged(provider: String?, st: Int, extras: Bundle?) {}
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun tv(text: String, size: Float = 15f, color: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(CARD, 20, STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(12)) }
    }
    private fun btn(text: String, fill: Int, color: Int, size: Float = 16f) = Button(this).apply {
        this.text = text; setTextColor(color); background = bg(fill, 14); isAllCaps = false; textSize = size
        setTypeface(typeface, Typeface.BOLD)
    }
    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint; setHintTextColor(MUTED); setTextColor(TEXT); background = bg(FIELD, 14, STROKE)
        setPadding(dp(14), dp(12), dp(14), dp(12)); textSize = 16f; gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setSingleLine(true)
    }
    private fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }
    private val openState = HashMap<TextView, Boolean>()
    private fun setTitle(h: TextView, title: String) {
        h.tag = title
        h.text = (if (openState[h] == true) "▼ " else "◄ ") + title
    }
    private fun collapsible(title: String, body: View): Pair<LinearLayout, TextView> {
        val c = card(); val h = tv("", 18f, TEXT, true)
        body.visibility = View.GONE; setTitle(h, title)
        h.setOnClickListener {
            val open = body.visibility != View.VISIBLE
            body.visibility = if (open) View.VISIBLE else View.GONE
            openState[h] = open; setTitle(h, h.tag as String)
        }
        c.addView(h); c.addView(body, lp(top = 10))
        return Pair(c, h)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG; window.navigationBarColor = BG
        ui()
        load()
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != null && r >= 0
                tts?.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            }
        }
        val missing = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
            .filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 4)
        render()
    }

    override fun onResume() { super.onResume(); startLocation() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startLocation()
    }

    // ---------- Screen ----------
    private fun ui() {
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(24)) }

        // Recorder name + date
        val head = card()
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nameEdit = edit("اسم المسجِّل").apply {
            setText(prefs.getString("recorder", "")); inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { prefs.edit().putString("recorder", s.toString()).apply() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        headRow.addView(nameEdit, LinearLayout.LayoutParams(0, WRAP, 1f))
        headRow.addView(tv(SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date()), 22f, TEXT, true).apply { setPadding(dp(16), 0, dp(4), 0) })
        head.addView(headRow); content.addView(head)

        // Counters + plate boxes + listen button
        val main = card()
        val counters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun counter(label: String, color: Int): TextView {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val num = tv("0", 44f, color, true).apply { gravity = Gravity.CENTER }
            col.addView(num); col.addView(tv(label, 20f, MUTED).apply { gravity = Gravity.CENTER })
            counters.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f)); return num
        }
        platesCount = counter("لوحات", TEXT)
        wantedCount = counter("مطلوبة", RED)
        main.addView(counters)

        val boxesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun box(list: MutableList<TextView>) {
            val b = TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 24f; setTextColor(TEXT); background = bg(FIELD, 14, STROKE)
            }
            list.add(b); boxesRow.addView(b, LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        repeat(3) { box(letterBoxes) }
        boxesRow.addView(View(this), LinearLayout.LayoutParams(0, dp(1), 0.5f))
        repeat(4) { box(digitBoxes) }
        main.addView(boxesRow, lp(top = 16))
        showPlate(null)

        status = tv("متوقف", 16f, MUTED).apply { gravity = Gravity.CENTER }
        spoken = tv("", 14f, MUTED).apply { gravity = Gravity.CENTER }
        main.addView(status, lp(top = 12)); main.addView(spoken, lp(top = 4))
        listenButton = btn("ابدأ الاستماع 🎤", TEAL, 0xFF06201C.toInt(), 22f).apply {
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        main.addView(listenButton, lp(h = dp(64), top = 16))
        content.addView(main)

        // Last plate
        val last = card()
        last.addView(tv("آخر لوحة", 15f, MUTED))
        lastPlateView = tv("—", 34f, TEAL, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
        last.addView(lastPlateView)
        last.addView(btn("⌫ مسح آخر حرف أو رقم", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { backspace() } }, lp(h = dp(48), top = 4))
        val lastBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lastBtns.addView(btn("✕ حذف آخر لوحة", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener { records.lastOrNull()?.let { deleteRecord(it) } ?: toast("السجل فارغ") }
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { topMargin = dp(8) })
        lastBtns.addView(btn("↩ مسح المربعات", 0xFF1F2A36.toInt(), TEXT, 15f).apply {
            setOnClickListener { assembler.reset(); utterStamp = null; showPlate(null); spoken.text = ""; setStatus("تم مسح المربعات") }
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8); topMargin = dp(8) })
        last.addView(lastBtns)
        content.addView(last)

        // Manual entry
        val manual = card()
        val manualRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = edit("إدخال يدوي: س ب ح 7831 تاكسي")
        manualRow.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        manualRow.addView(btn("إضافة", 0xFF1D4A42.toInt(), TEAL).apply {
            setOnClickListener {
                val before = records.size
                val tmp = PlateAssembler(); val snk = RecSink("manual")
                tmp.feed(input.text.toString(), currentStamp(), snk); tmp.flush(snk)
                if (records.size == before) toast("تعذر فهم اللوحة؛ اكتب مثل: س ر ط 7520 تاكسي") else input.setText("")
            }
        }, LinearLayout.LayoutParams(WRAP, dp(52)).apply { marginStart = dp(10) })
        manual.addView(manualRow); content.addView(manual)

        // Wanted list
        val wantedBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wantedBody.addView(tv("استورد ملف Excel (XLSX) أو CSV فيه عمود اللوحات.", 13f, MUTED))
        wantedBody.addView(Switch(this).apply {
            text = "🔔 صوت وتنبيه عند اللوحة المطلوبة"; setTextColor(TEXT); textSize = 15f
            isChecked = prefs.getBoolean("alert_sound", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("alert_sound", c).apply() }
        }, lp(top = 10))
        wantedBody.addView(btn("استيراد المطلوبين من Excel أو CSV", 0xFF1D4A42.toInt(), TEAL, 15f).apply {
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/plain", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                }
                startActivityForResult(i, 10)
            }
        }, lp(top = 8))
        wantedBody.addView(btn("مسح قائمة المطلوبين", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("مسح قائمة المطلوبين؟")
                    .setPositiveButton("مسح") { _, _ ->
                        wanted.clear(); saveWanted()
                        records.forEach { it.put("matched", false) }; persist(); render()
                    }.setNegativeButton("إلغاء", null).show()
            }
        }, lp(top = 8))
        val (wantedCard, wh) = collapsible("قائمة المطلوبين (0)", wantedBody)
        wantedHeader = wh; content.addView(wantedCard)

        // Speech engine
        val engineBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val modeNames = listOf("محلي من أندرويد (قد يحتاج إنترنت)", "Deepgram مباشر", "Deepgram + Gemini عند الحاجة", "Gemini Live مباشر")
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        modeNames.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply { id = 100 + i; text = n; setTextColor(TEXT); textSize = 16f; isChecked = i == mode() })
        }
        group.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("mode", id - 100).apply() }
        engineBody.addView(group)
        engineBody.addView(btn("⚙️ مفاتيح Deepgram وGemini", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { showApiSettings() } }, lp(top = 8))
        content.addView(collapsible("محرك التعرف على الكلام", engineBody).first)

        // Teach letters
        content.addView(collapsible("تعليم المايك الحروف", mapEditor("letter_map",
            "لو المايك يسمع الحرف بكلمة مختلفة، علّمه: اكتب الكلمة كما يسمعها والحرف المقصود.",
            "الكلمة المسموعة (مثل: سن)", "الحرف (مثل: س)", true) { PlateParser.extraLetters = it }).first)

        // Word corrections
        content.addView(collapsible("تصحيح الكلمات", mapEditor("corr_map",
            "استبدل كلمة يخطئ فيها التفريغ بالكلمة الصحيحة قبل استخراج اللوحة.",
            "الكلمة الخاطئة", "الكلمة الصحيحة", false) { PlateParser.corrections = it }).first)

        // Log
        val log = card()
        val logHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        logHead.addView(tv("السجل", 20f, TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        logHead.addView(btn("Excel 📥", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { export() } }, LinearLayout.LayoutParams(WRAP, dp(48)))
        logHead.addView(btn("🗑️ مسح السجل", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("مسح كل السجل؟ لا يمكن التراجع.")
                    .setPositiveButton("مسح") { _, _ -> records.clear(); assembler.reset(); persist(); render(); showPlate(null); lastPlateView.text = "—" }
                    .setNegativeButton("إلغاء", null).show()
            }
        }, LinearLayout.LayoutParams(WRAP, dp(48)).apply { marginStart = dp(8) })
        log.addView(logHead)
        undoBtn = btn("↩ تراجع", 0xFF1F2A36.toInt(), TEXT, 14f).apply {
            visibility = View.GONE
            setOnClickListener {
                lastDeleted?.let { records.add(it); records.sortBy { x -> x.optLong("epoch") }; persist(); render() }
                lastDeleted = null; visibility = View.GONE
            }
        }
        log.addView(undoBtn, lp(h = dp(44), top = 8))
        log.addView(tv("✕ يحذف اللوحة كلها، واضغط على رقم اللوحة لتصحيحها", 12f, MUTED), lp(top = 8))
        log.addView(row("اللوحة", "النوع", "الحالة", "الوقت", "الموقع", true, MUTED, null, null), lp(top = 12))
        recordsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log.addView(recordsBox)
        content.addView(log)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG); layoutDirection = View.LAYOUT_DIRECTION_RTL; isFillViewport = true
            addView(content)
        })
    }

    private fun row(plate: String, type: String, st: String, time: String, loc: String, header: Boolean, stColor: Int,
                    onLoc: (() -> Unit)?, onDel: (() -> Unit)?, onEdit: (() -> Unit)? = null): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        fun cell(t: String, w: Float, col: Int, bold: Boolean = false): TextView =
            tv(t, 13f, col, bold).apply { gravity = Gravity.START }.also { r.addView(it, LinearLayout.LayoutParams(0, WRAP, w)) }
        val base = if (header) MUTED else TEXT
        val d = cell(if (onDel != null) "✕" else "", 0.5f, RED, true)
        d.textSize = 20f
        if (onDel != null) { d.setPadding(0, dp(8), 0, dp(8)); d.setOnClickListener { onDel() } }
        val pc = cell(plate, 1.4f, base, !header)
        if (onEdit != null) { pc.setPadding(0, dp(8), 0, dp(8)); pc.setOnClickListener { onEdit() } }
        cell(type, 0.9f, base)
        cell(st, 1f, if (header) MUTED else stColor)
        cell(time, 1.1f, base)
        val l = cell(loc, 0.9f, if (onLoc != null) TEAL else base, onLoc != null)
        if (onLoc != null) { l.setPadding(0, dp(8), 0, dp(8)); l.setOnClickListener { onLoc() } }
        return r
    }

    private fun showPlate(p: String?) = showDraft(p?.take(3).orEmpty(), p?.drop(3).orEmpty())

    private fun showDraft(letters: String, digits: String) {
        letterBoxes.forEachIndexed { i, b -> b.text = letters.getOrNull(i)?.toString() ?: "" }
        digitBoxes.forEachIndexed { i, b -> b.text = digits.getOrNull(i)?.toString() ?: "•" }
    }

    private fun mapEditor(prefKey: String, desc: String, hintFrom: String, hintTo: String, singleLetter: Boolean, onChange: (Map<String, String>) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv(desc, 13f, MUTED))
        val from = edit(hintFrom); val to = edit(hintTo)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun read(): MutableMap<String, String> {
            val m = linkedMapOf<String, String>()
            try { val o = JSONObject(prefs.getString(prefKey, "{}") ?: "{}"); o.keys().forEach { m[it] = o.getString(it) } } catch (_: Exception) {}
            return m
        }
        fun write(m: Map<String, String>) { prefs.edit().putString(prefKey, JSONObject(m as Map<*, *>).toString()).apply() }
        fun refresh() {
            val m = read(); onChange(m); list.removeAllViews()
            m.forEach { (k, v) ->
                list.addView(tv("$k  ←  $v      ✕", 15f, TEXT).apply {
                    setPadding(0, dp(8), 0, dp(8))
                    setOnClickListener { val mm = read(); mm.remove(k); write(mm); refresh() }
                })
            }
        }
        box.addView(from, lp(top = 8)); box.addView(to, lp(top = 8))
        box.addView(btn("إضافة", 0xFF1D4A42.toInt(), TEAL, 15f).apply {
            setOnClickListener {
                val k = from.text.toString().trim(); val v = to.text.toString().trim()
                if (k.isBlank() || v.isBlank()) { toast("اكتب الحقلين"); return@setOnClickListener }
                if (singleLetter && !(v.length == 1 && v[0] in '\u0621'..'\u064A')) { toast("اكتب حرفًا عربيًا واحدًا"); return@setOnClickListener }
                val m = read(); m[k] = v; write(m); from.setText(""); to.setText(""); refresh()
            }
        }, lp(top = 8))
        box.addView(list, lp(top = 8))
        refresh()
        return box
    }

    // ---------- Listening ----------
    private fun setListeningUi(on: Boolean) {
        listening = on
        listenButton.text = if (on) "⏹ إيقاف الاستماع" else "ابدأ الاستماع 🎤"
        listenButton.background = bg(if (on) RED else TEAL, 14)
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    private fun setStatus(s: String, color: Int = MUTED) { status.text = s; status.setTextColor(color) }

    private fun hasMic() = ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startListening() {
        if (!hasMic()) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 4); return }
        when (mode()) {
            3 -> {
                val gk = prefs.getString("gemini_key", "").orEmpty()
                if (gk.isBlank()) { showApiSettings(); toast("أدخل مفتاح Gemini أولًا"); return }
                setListeningUi(true); setStatus("جاري الاتصال بـ Gemini Live…")
                liveSpeech = GeminiLiveSpeech({ transcript, isFinal -> runOnUiThread { onTranscript(transcript, isFinal, "gemini-live") } },
                    { message -> runOnUiThread {
                        setStatus(message)
                        if (message.startsWith("تعذر")) setListeningUi(false)
                    } }).also { it.start(gk) }
            }
            1, 2 -> {
                val dg = prefs.getString("deepgram_key", "").orEmpty()
                if (dg.isBlank()) { showApiSettings(); toast("أدخل مفتاح Deepgram أولًا"); return }
                setListeningUi(true); setStatus("جاري الاتصال بـ Deepgram…")
                cloudSpeech = CloudSpeech({ transcript, isFinal -> runOnUiThread {
                    val snapBefore = snapshot()
                    onTranscript(transcript, isFinal, if (mode() == 2) "deepgram+gemini" else "deepgram")
                    if (isFinal && mode() == 2 && snapshot() == snapBefore && transcript.isNotBlank()) {
                        setStatus("النص غير واضح؛ Gemini يحاول استخراج اللوحة…")
                        Thread {
                            val p = GeminiPlateHelper.extractPlate(prefs.getString("gemini_key", "").orEmpty(), transcript)
                            runOnUiThread {
                                if (!p.isNullOrBlank() && listening)
                                    onTranscript(p.take(3).toList().joinToString(" ") + " " + p.drop(3), true, "deepgram+gemini")
                                else if (listening) setStatus("لم يتم استخراج لوحة مؤكدة")
                            }
                        }.start()
                    }
                } }, { message -> runOnUiThread {
                    setStatus(message)
                    if (message.startsWith("تعذر")) setListeningUi(false)
                } }).also { it.start(dg) }
            }
            else -> startLocalRecognition()
        }
    }

    private fun startLocalRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("خدمة التعرف على الكلام غير متاحة"); return }
        setListeningUi(true); setStatus("🎙️ جاري الاستماع")
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { sr?.destroy() } catch (_: Exception) {}
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("الميكروفون جاهز") }
            override fun onBeginningOfSpeech() { setStatus("بسمعك...") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restart(intent) }
            override fun onResults(results: Bundle?) {
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onTranscript(it, true, "voice") }
                restart(intent)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onTranscript(it, false, "voice") }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { sr?.startListening(intent) } catch (_: Exception) { setStatus("تعذر بدء الميكروفون") }
    }

    private fun restart(intent: Intent) {
        if (!listening) return
        window.decorView.postDelayed({
            if (listening) try { sr?.cancel(); sr?.startListening(intent) }
            catch (_: Exception) { setStatus("توقف الاستماع؛ اضغط ابدأ الاستماع مرة أخرى") }
        }, 400)
    }

    private fun stopListening() {
        assembler.flush(RecSink("voice"))
        utterStamp = null
        setListeningUi(false)
        try { cloudSpeech?.stop() } catch (_: Exception) {}; cloudSpeech = null
        try { liveSpeech?.stop() } catch (_: Exception) {}; liveSpeech = null
        try { sr?.cancel(); sr?.destroy() } catch (_: Exception) {}
        sr = null; setStatus("متوقف")
    }

    // ---------- Location ----------
    private fun hasLoc() = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startLocation() {
        if (!hasLoc()) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            lm.removeUpdates(locListener)
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { p ->
                try { if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 5000L, 0f, locListener) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun location(): Location? {
        if (!hasLoc()) return null
        return try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            listOfNotNull(
                lastLoc,
                try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Exception) { null },
                try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { null }
            ).maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    /** Opens the map app (GPS position) at the saved coordinates. */
    private fun openMap(lat: Double, lon: Double) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")))
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lon"))) }
            catch (_: Exception) { toast("لا يوجد تطبيق خرائط") }
        }
    }

    // ---------- Data ----------
    private fun currentStamp(): PlateAssembler.Stamp {
        val l = location()
        return PlateAssembler.Stamp(System.currentTimeMillis(), l?.latitude, l?.longitude)
    }
    private fun snapshot(): String = records.size.toString() + "|" + (assembler.cur?.let { it.letters + "." + it.digits } ?: "")

    /** Called for every speech result. Interim results only preview; final results are assembled into plates. */
    private fun onTranscript(text: String, isFinal: Boolean, method: String) {
        spoken.text = text
        if (utterStamp == null) utterStamp = currentStamp() // time + GPS of the moment speech started
        val stamp = utterStamp!!
        if (isFinal) {
            assembler.feed(text, stamp, RecSink(method))
            utterStamp = null
            assembler.cur?.let { showDraft(it.letters, it.digits) }
        } else {
            assembler.peek(text, stamp)?.let { showDraft(it.letters, it.digits) }
        }
    }

    private inner class RecSink(val method: String) : PlateAssembler.Sink {
        override fun upsert(d: PlateAssembler.Draft, incomplete: Boolean) = upsertRecord(d, incomplete, method)
    }

    private fun nextId(): Long { idCounter = maxOf(idCounter + 1, System.currentTimeMillis()); return idCounter }

    private fun upsertRecord(d: PlateAssembler.Draft, incomplete: Boolean, method: String) {
        val plate = d.letters + if (d.digits.length == 3) "0" + d.digits else d.digits
        var r = if (d.recordId >= 0) records.firstOrNull { it.optLong("id") == d.recordId } else null
        if (r == null && !incomplete) {
            val last = records.lastOrNull()
            if (last != null && last.optString("plate") == plate && d.stamp.ms - last.optLong("epoch") < 8000) {
                d.recordId = last.optLong("id"); r = last
            }
        }
        if (r == null) {
            d.recordId = nextId()
            r = JSONObject().apply {
                put("id", d.recordId); put("epoch", d.stamp.ms); put("timestamp", fmt.format(Date(d.stamp.ms)))
                put("lat", d.stamp.lat ?: JSONObject.NULL); put("lon", d.stamp.lon ?: JSONObject.NULL)
                put("method", method); put("recorder", nameEdit.text.toString().trim()); put("matched", false)
            }
            records.add(r)
        }
        val wasMatched = r.optBoolean("matched")
        val isWanted = !incomplete && wanted.contains(plate)
        r.put("plate", plate); r.put("type", d.type ?: ""); r.put("incomplete", incomplete); r.put("matched", isWanted)
        persist(); render()
        showDraft(d.letters, d.digits)
        lastPlateView.text = plate + (d.type?.let { "  ·  $it" } ?: "")
        lastPlateView.setTextColor(if (isWanted) RED else TEAL)
        when {
            isWanted -> {
                setStatus("⚠️ $plate مطلوبة!", RED)
                if (!wasMatched) alertWanted(plate)
            }
            incomplete -> setStatus("سُجّل $plate — كمّل الباقي أو قل لوحة جديدة")
            else -> setStatus("تم تسجيل $plate")
        }
    }

    private fun draftFromRecord(r: JSONObject): PlateAssembler.Draft {
        val plate = r.optString("plate")
        val letters = plate.takeWhile { it in '\u0621'..'\u064A' }.take(3)
        var digits = plate.drop(letters.length)
        if (digits.length == 4 && digits.startsWith("0")) digits = digits.drop(1)
        val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
        return PlateAssembler.Draft(letters, digits, r.optString("type").ifBlank { null },
            PlateAssembler.Stamp(r.optLong("epoch"), if (lat.isFinite()) lat else null, if (lon.isFinite()) lon else null), r.optLong("id"))
    }

    /** Removes the last digit (or last letter) of the plate being built, or of the last saved plate. */
    private fun backspace() {
        var d = assembler.cur
        if (d == null) {
            val r = records.lastOrNull() ?: run { toast("لا توجد لوحة"); return }
            d = draftFromRecord(r); assembler.adopt(d)
        }
        if (d.digits.isNotEmpty()) d.digits = d.digits.dropLast(1)
        else if (d.letters.isNotEmpty()) d.letters = d.letters.dropLast(1)
        if (d.letters.isEmpty() && d.digits.isEmpty()) {
            records.removeAll { it.optLong("id") == d.recordId }
            assembler.reset(); persist(); render(); showPlate(null); lastPlateView.text = "—"; setStatus("تم مسح اللوحة")
        } else RecSink("edit").upsert(d, d.letters.length < 3 || d.digits.length < 3)
    }

    /** Fix a wrongly read plate: change the plate text and/or the vehicle type. */
    private fun editRecord(r: JSONObject) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val plateEt = EditText(this).apply { hint = "اللوحة: س ر ط 7520"; setText(r.optString("plate")); setSingleLine(true) }
        val typeEt = EditText(this).apply { hint = "النوع (تاكسي، وانيت، نقل، ميكروباص، يامه)"; setText(r.optString("type")); setSingleLine(true) }
        box.addView(plateEt); box.addView(typeEt)
        AlertDialog.Builder(this).setTitle("تصحيح اللوحة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                var got: PlateAssembler.Draft? = null
                val grab = object : PlateAssembler.Sink { override fun upsert(d: PlateAssembler.Draft, incomplete: Boolean) { got = d.copyDraft() } }
                val tmp = PlateAssembler()
                tmp.feed(plateEt.text.toString(), PlateAssembler.Stamp(r.optLong("epoch"), null, null), grab); tmp.flush(grab)
                val g = got
                if (g == null) { toast("اكتب 3 حروف وأرقام، مثل: س ر ط 7520"); return@setPositiveButton }
                val plate = g.letters + if (g.digits.length == 3) "0" + g.digits else g.digits
                val incomplete = g.letters.length < 3 || g.digits.length < 3
                r.put("plate", plate); r.put("incomplete", incomplete); r.put("matched", !incomplete && wanted.contains(plate))
                r.put("type", typeEt.text.toString().trim().ifBlank { g.type ?: "" })
                if (assembler.cur?.recordId == r.optLong("id")) assembler.adopt(draftFromRecord(r))
                persist(); render()
                if (records.lastOrNull() === r) { showPlate(plate); lastPlateView.text = plate }
            }.setNegativeButton("إلغاء", null).show()
    }

    private var lastDeleted: JSONObject? = null
    private lateinit var undoBtn: Button

    /** Deletes the whole plate immediately; "تراجع" restores it. */
    /** Vibrates, sounds an alarm tone, then says "مطلوبة" (once per plate). */
    private fun alertWanted(plate: String) {
        try { (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
        if (!prefs.getBoolean("alert_sound", true)) return
        try {
            val tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900)
            window.decorView.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1500)
        } catch (_: Exception) {}
        window.decorView.postDelayed({
            if (ttsReady) tts?.speak("مطلوبة", TextToSpeech.QUEUE_FLUSH, null, "wanted-$plate")
        }, 1000)
    }

    private fun deleteRecord(r: JSONObject) {
        val id = r.optLong("id")
        records.removeAll { it.optLong("id") == id }
        assembler.dropRecord(id)
        lastDeleted = r
        undoBtn.text = "↩ تراجع عن حذف ${r.optString("plate")}"; undoBtn.visibility = View.VISIBLE
        persist(); render(); setStatus("تم حذف ${r.optString("plate")}")
        records.lastOrNull().let { if (it == null) { showPlate(null); lastPlateView.text = "—" } }
    }

    private fun load() {
        try {
            val f = File(filesDir, "records.json")
            if (f.exists()) { val a = JSONArray(f.readText()); for (i in 0 until a.length()) records.add(a.getJSONObject(i)) }
        } catch (_: Exception) {}
        try {
            val w = File(filesDir, "wanted.txt")
            if (w.exists()) w.readLines().filter { it.isNotBlank() }.forEach { wanted.add(it.trim()) }
        } catch (_: Exception) {}
        records.forEach { if (it.optLong("id") == 0L) it.put("id", nextId()) }
        persist()
        records.lastOrNull()?.let { showPlate(it.optString("plate")); lastPlateView.text = it.optString("plate") }
    }
    private fun persist() {
        try { val a = JSONArray(); records.forEach { a.put(it) }; File(filesDir, "records.json").writeText(a.toString()) }
        catch (_: Exception) { toast("تعذر حفظ السجلات") }
    }
    private fun saveWanted() {
        try { File(filesDir, "wanted.txt").writeText(wanted.joinToString("\n")) } catch (_: Exception) { toast("تعذر حفظ قائمة المطلوبين") }
    }

    private fun render() {
        if (!::recordsBox.isInitialized) return
        platesCount.text = records.size.toString()
        wantedCount.text = records.count { it.optBoolean("matched") }.toString()
        setTitle(wantedHeader, "قائمة المطلوبين (${wanted.size})")
        recordsBox.removeAllViews()
        records.takeLast(100).reversed().forEach { r ->
            val matched = r.optBoolean("matched"); val incomplete = r.optBoolean("incomplete")
            val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
            val located = lat.isFinite() && lon.isFinite()
            val st = if (matched) "مطلوبة" else if (incomplete) "ناقصة" else "عادية"
            val stColor = if (matched) RED else if (incomplete) 0xFFE0B341.toInt() else MUTED
            recordsBox.addView(row(
                r.optString("plate"), r.optString("type").ifBlank { "—" }, st,
                r.optString("timestamp").substringAfter(' '), if (located) "📍 فتح" else "—",
                false, stColor, if (located) ({ openMap(lat, lon) }) else null, { deleteRecord(r) }, { editRecord(r) }
            ).apply { background = bg(if (matched) 0xFF2A1B20.toInt() else CARD, 10) })
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            try {
                val uri = data?.data ?: return
                val imported = SpreadsheetReader.readPlateColumn(contentResolver, uri)
                    .mapNotNull { PlateParser.normalize(it).takeIf(String::isNotBlank) }
                wanted.clear(); wanted.addAll(imported); saveWanted()
                records.forEach { it.put("matched", wanted.contains(it.optString("plate"))) }
                persist(); render(); toast("تم استيراد ${wanted.size} لوحة ومطابقة السجلات")
            } catch (e: Exception) {
                toast(e.message ?: "تعذر قراءة الملف؛ جرّب XLSX أو CSV")
            }
        }
    }

    private fun export() {
        if (records.isEmpty()) { toast("السجل فارغ"); return }
        try {
            val rows = records.map { r ->
                val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
                val ok = lat.isFinite() && lon.isFinite()
                listOf(
                    XlsxWriter.Cell(r.optString("plate")),
                    if (ok) XlsxWriter.Cell(String.format(Locale.US, "%.6f, %.6f", lat, lon), "https://maps.google.com/?q=$lat,$lon") else XlsxWriter.Cell(""),
                    XlsxWriter.Cell(r.optString("type")),
                    XlsxWriter.Cell(r.optString("timestamp")),
                    XlsxWriter.Cell(if (r.optBoolean("matched")) "مطلوبة" else if (r.optBoolean("incomplete")) "ناقصة" else "عادية"),
                    XlsxWriter.Cell(r.optString("recorder"))
                )
            }
            val name = "plates_" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) + ".xlsx"
            val f = File(cacheDir, name)
            XlsxWriter.write(f, "السجل", listOf("اللوحة", "الموقع", "النوع", "الوقت", "الحالة", "المسجِّل"),
                setOf(0, 1, 2), listOf(16, 26, 14, 20, 12, 16), rows)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "تصدير ملف Excel"))
        } catch (e: Exception) { toast("تعذر التصدير: ${e.message}") }
    }

    private fun showApiSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val deepgram = EditText(this).apply { hint = "Deepgram API Key"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("deepgram_key", "")) }
        val gemini = EditText(this).apply { hint = "Gemini API Key (لوضع Gemini Live والاحتياطي)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("gemini_key", "")) }
        box.addView(TextView(this).apply { text = "للاستخدام الشخصي فقط: حفظ المفتاح داخل الهاتف ليس حماية كاملة. لا تنشر APK بمفاتيحك."; textSize = 13f })
        box.addView(deepgram); box.addView(gemini)
        AlertDialog.Builder(this).setTitle("إعداد مفاتيح API").setView(box)
            .setPositiveButton("حفظ") { _, _ -> prefs.edit().putString("deepgram_key", deepgram.text.toString().trim()).putString("gemini_key", gemini.text.toString().trim()).apply(); toast("تم حفظ الإعدادات على هذا الهاتف") }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() {
        listening = false
        try { cloudSpeech?.stop() } catch (_: Exception) {}
        try { liveSpeech?.stop() } catch (_: Exception) {}
        try { sr?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        try { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locListener) } catch (_: Exception) {}
        super.onDestroy()
    }
}
